# Password Manager                                                                                                                                                         
A simple password manager written in c
